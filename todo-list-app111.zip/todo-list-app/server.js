require("dotenv").config();

const path = require("path");
const express = require("express");
const mongoose = require("mongoose");
const taskRoutes = require("./routes/tasks");

const app = express();
const PORT = process.env.PORT || 3000;
const MONGODB_URI =
  process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/taskflow";

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname)));

app.use("/api/tasks", taskRoutes);

app.get("/", (request, response) => {
  response.sendFile(path.join(__dirname, "main.html"));
});

app.use((request, response) => {
  response.status(404).json({ message: "Route not found." });
});

app.use((error, request, response, next) => {
  console.error(error);

  if (error.name === "ValidationError") {
    return response.status(400).json({
      message: "Validation failed.",
      errors: Object.values(error.errors).map((item) => item.message)
    });
  }

  response.status(500).json({
    message: "An unexpected server error occurred."
  });
});

async function startServer() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log("Connected to MongoDB.");

    app.listen(PORT, () => {
      console.log(`TaskFlow is running at http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("Unable to start the server:", error.message);
    process.exit(1);
  }
}

startServer();
