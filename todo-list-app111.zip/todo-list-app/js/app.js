const API_URL = "/api/tasks";
const LOCAL_STORAGE_KEY = "taskflow_tasks";
const THEME_KEY = "taskflow_theme";

const state = {
  tasks: [],
  filter: "all",
  search: "",
  storageMode: "checking"
};

const elements = {
  form: document.querySelector("#task-form"),
  title: document.querySelector("#task-title"),
  description: document.querySelector("#task-description"),
  dueDate: document.querySelector("#task-due-date"),
  priority: document.querySelector("#task-priority"),
  titleError: document.querySelector("#title-error"),
  list: document.querySelector("#task-list"),
  emptyState: document.querySelector("#empty-state"),
  totalCount: document.querySelector("#total-count"),
  activeCount: document.querySelector("#active-count"),
  completedCount: document.querySelector("#completed-count"),
  progressText: document.querySelector("#progress-text"),
  progressBar: document.querySelector("#progress-bar"),
  progressTrack: document.querySelector(".progress-track"),
  filters: document.querySelectorAll(".filter-button"),
  search: document.querySelector("#task-search"),
  connectionStatus: document.querySelector("#connection-status"),
  toast: document.querySelector("#toast"),
  themeToggle: document.querySelector("#theme-toggle")
};

document.addEventListener("DOMContentLoaded", initializeApp);

async function initializeApp() {
  initializeTheme();
  bindEvents();
  setMinimumDueDate();
  await loadTasks();
}

function bindEvents() {
  elements.form.addEventListener("submit", handleAddTask);
  elements.title.addEventListener("input", clearTitleError);
  elements.list.addEventListener("change", handleTaskToggle);
  elements.list.addEventListener("click", handleTaskAction);

  elements.filters.forEach((button) => {
    button.addEventListener("click", () => {
      state.filter = button.dataset.filter;

      elements.filters.forEach((item) => {
        const isActive = item === button;
        item.classList.toggle("active", isActive);
        item.setAttribute("aria-pressed", String(isActive));
      });

      renderTasks();
    });
  });

  elements.search.addEventListener("input", (event) => {
    state.search = event.target.value.trim().toLowerCase();
    renderTasks();
  });

  elements.themeToggle.addEventListener("click", toggleTheme);
}

function setMinimumDueDate() {
  const today = new Date().toISOString().split("T")[0];
  elements.dueDate.min = today;
}

async function loadTasks() {
  try {
    const response = await fetch(API_URL, {
      headers: { Accept: "application/json" }
    });

    if (!response.ok) {
      throw new Error("API request failed");
    }

    state.tasks = await response.json();
    state.storageMode = "api";
    updateConnectionStatus();
  } catch (error) {
    state.tasks = readLocalTasks();
    state.storageMode = "local";
    updateConnectionStatus();
  }

  sortTasks();
  renderTasks();
}

async function handleAddTask(event) {
  event.preventDefault();

  const title = elements.title.value.trim();

  if (!title) {
    showTitleError("Please enter a task title.");
    elements.title.focus();
    return;
  }

  const newTask = {
    title,
    description: elements.description.value.trim(),
    dueDate: elements.dueDate.value || null,
    priority: elements.priority.value,
    completed: false
  };

  try {
    const createdTask = await createTask(newTask);
    state.tasks.push(createdTask);
    sortTasks();
    elements.form.reset();
    elements.priority.value = "medium";
    renderTasks();
    showToast("Task added successfully.");
    elements.title.focus();
  } catch (error) {
    showToast("Unable to add the task.");
  }
}

async function createTask(task) {
  if (state.storageMode === "api") {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(task)
    });

    if (!response.ok) {
      throw new Error("Unable to create task");
    }

    return response.json();
  }

  const localTask = {
    ...task,
    _id: createLocalId(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const nextTasks = [...state.tasks, localTask];
  saveLocalTasks(nextTasks);
  return localTask;
}

async function handleTaskToggle(event) {
  if (!event.target.matches(".task-checkbox")) {
    return;
  }

  const taskId = event.target.dataset.id;
  const task = state.tasks.find((item) => item._id === taskId);

  if (!task) {
    return;
  }

  const previousValue = task.completed;
  task.completed = event.target.checked;
  renderTasks();

  try {
    const updatedTask = await updateTask(taskId, { completed: task.completed });
    replaceTask(updatedTask);
    showToast(task.completed ? "Task completed." : "Task marked active.");
  } catch (error) {
    task.completed = previousValue;
    renderTasks();
    showToast("Unable to update the task.");
  }
}

async function handleTaskAction(event) {
  const deleteButton = event.target.closest("[data-action='delete']");

  if (!deleteButton) {
    return;
  }

  const taskId = deleteButton.dataset.id;
  const task = state.tasks.find((item) => item._id === taskId);

  if (!task) {
    return;
  }

  const confirmed = window.confirm(`Delete "${task.title}"?`);

  if (!confirmed) {
    return;
  }

  try {
    await deleteTask(taskId);
    state.tasks = state.tasks.filter((item) => item._id !== taskId);

    if (state.storageMode === "local") {
      saveLocalTasks(state.tasks);
    }

    renderTasks();
    showToast("Task deleted.");
  } catch (error) {
    showToast("Unable to delete the task.");
  }
}

async function updateTask(taskId, updates) {
  if (state.storageMode === "api") {
    const response = await fetch(`${API_URL}/${taskId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates)
    });

    if (!response.ok) {
      throw new Error("Unable to update task");
    }

    return response.json();
  }

  const updatedTask = {
    ...state.tasks.find((task) => task._id === taskId),
    ...updates,
    updatedAt: new Date().toISOString()
  };

  const nextTasks = state.tasks.map((task) =>
    task._id === taskId ? updatedTask : task
  );

  saveLocalTasks(nextTasks);
  return updatedTask;
}

async function deleteTask(taskId) {
  if (state.storageMode === "api") {
    const response = await fetch(`${API_URL}/${taskId}`, {
      method: "DELETE"
    });

    if (!response.ok) {
      throw new Error("Unable to delete task");
    }
  }
}

function replaceTask(updatedTask) {
  state.tasks = state.tasks.map((task) =>
    task._id === updatedTask._id ? updatedTask : task
  );

  if (state.storageMode === "local") {
    saveLocalTasks(state.tasks);
  }

  sortTasks();
  renderTasks();
}

function renderTasks() {
  const filteredTasks = state.tasks.filter((task) => {
    const matchesFilter =
      state.filter === "all" ||
      (state.filter === "active" && !task.completed) ||
      (state.filter === "completed" && task.completed);

    const searchableText = `${task.title} ${task.description || ""}`.toLowerCase();
    const matchesSearch = searchableText.includes(state.search);

    return matchesFilter && matchesSearch;
  });

  elements.list.innerHTML = filteredTasks.map(createTaskMarkup).join("");

  const shouldShowEmpty = filteredTasks.length === 0;
  elements.emptyState.classList.toggle("hidden", !shouldShowEmpty);

  if (shouldShowEmpty) {
    const heading = elements.emptyState.querySelector("h3");
    const paragraph = elements.emptyState.querySelector("p");

    if (state.tasks.length === 0) {
      heading.textContent = "No tasks yet";
      paragraph.textContent = "Add your first task using the form.";
    } else {
      heading.textContent = "No matching tasks";
      paragraph.textContent = "Try changing your search or filter.";
    }
  }

  updateStatistics();
}

function createTaskMarkup(task) {
  const dueInfo = getDueDateInfo(task.dueDate);
  const description = task.description
    ? `<p class="task-description">${escapeHtml(task.description)}</p>`
    : "";

  return `
    <article class="task-item ${task.completed ? "completed" : ""}">
      <input
        class="task-checkbox"
        type="checkbox"
        data-id="${escapeHtml(task._id)}"
        aria-label="${task.completed ? "Mark task as active" : "Mark task as completed"}: ${escapeHtml(task.title)}"
        ${task.completed ? "checked" : ""}
      >

      <div class="task-content">
        <div class="task-title-row">
          <a class="task-title" href="task.html?id=${encodeURIComponent(task._id)}">
            ${escapeHtml(task.title)}
          </a>
          <span class="priority-badge priority-${escapeHtml(task.priority)}">
            ${escapeHtml(task.priority)}
          </span>
        </div>

        ${description}

        <div class="task-meta">
          ${dueInfo.markup}
          <span>Created ${formatDate(task.createdAt)}</span>
        </div>
      </div>

      <div class="task-actions" aria-label="Actions for ${escapeHtml(task.title)}">
        <a
          class="small-action"
          href="task.html?id=${encodeURIComponent(task._id)}"
          aria-label="View or edit ${escapeHtml(task.title)}"
          title="View or edit"
        >✎</a>
        <button
          class="small-action delete"
          type="button"
          data-action="delete"
          data-id="${escapeHtml(task._id)}"
          aria-label="Delete ${escapeHtml(task.title)}"
          title="Delete task"
        >×</button>
      </div>
    </article>
  `;
}

function getDueDateInfo(dateString) {
  if (!dateString) {
    return { markup: "" };
  }

  const dueDate = new Date(`${dateString}T23:59:59`);
  const today = new Date();
  const isOverdue = dueDate < today;

  return {
    markup: `
      <span class="due-badge ${isOverdue ? "overdue" : ""}">
        ${isOverdue ? "Overdue" : "Due"} ${formatDate(dateString)}
      </span>
    `
  };
}

function updateStatistics() {
  const total = state.tasks.length;
  const completed = state.tasks.filter((task) => task.completed).length;
  const active = total - completed;
  const percentage = total === 0 ? 0 : Math.round((completed / total) * 100);

  elements.totalCount.textContent = total;
  elements.activeCount.textContent = active;
  elements.completedCount.textContent = completed;
  elements.progressText.textContent = `${percentage}%`;
  elements.progressBar.style.width = `${percentage}%`;
  elements.progressTrack.setAttribute("aria-valuenow", String(percentage));
}

function updateConnectionStatus() {
  const text = elements.connectionStatus.querySelector("span:last-child");
  elements.connectionStatus.classList.remove("online", "local");

  if (state.storageMode === "api") {
    elements.connectionStatus.classList.add("online");
    text.textContent = "MongoDB API connected";
  } else {
    elements.connectionStatus.classList.add("local");
    text.textContent = "LocalStorage mode";
  }
}

function sortTasks() {
  const priorityRank = { high: 0, medium: 1, low: 2 };

  state.tasks.sort((a, b) => {
    if (a.completed !== b.completed) {
      return Number(a.completed) - Number(b.completed);
    }

    if (priorityRank[a.priority] !== priorityRank[b.priority]) {
      return priorityRank[a.priority] - priorityRank[b.priority];
    }

    return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
  });
}

function readLocalTasks() {
  try {
    const storedTasks = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY));
    return Array.isArray(storedTasks) ? storedTasks : [];
  } catch (error) {
    return [];
  }
}

function saveLocalTasks(tasks) {
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(tasks));
}

function createLocalId() {
  if (window.crypto && typeof window.crypto.randomUUID === "function") {
    return window.crypto.randomUUID();
  }

  return `local-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function formatDate(dateValue) {
  if (!dateValue) {
    return "";
  }

  const date =
    typeof dateValue === "string" && /^\d{4}-\d{2}-\d{2}$/.test(dateValue)
      ? new Date(`${dateValue}T12:00:00`)
      : new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return "";
  }

  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  }).format(date);
}

function showTitleError(message) {
  elements.titleError.textContent = message;
  elements.title.setAttribute("aria-invalid", "true");
}

function clearTitleError() {
  elements.titleError.textContent = "";
  elements.title.removeAttribute("aria-invalid");
}

let toastTimer;

function showToast(message) {
  window.clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.add("visible");

  toastTimer = window.setTimeout(() => {
    elements.toast.classList.remove("visible");
  }, 2600);
}

function initializeTheme() {
  const savedTheme = localStorage.getItem(THEME_KEY);
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const useDarkTheme = savedTheme ? savedTheme === "dark" : prefersDark;

  document.body.classList.toggle("dark-theme", useDarkTheme);
  updateThemeButton(useDarkTheme);
}

function toggleTheme() {
  const useDarkTheme = !document.body.classList.contains("dark-theme");
  document.body.classList.toggle("dark-theme", useDarkTheme);
  localStorage.setItem(THEME_KEY, useDarkTheme ? "dark" : "light");
  updateThemeButton(useDarkTheme);
}

function updateThemeButton(isDark) {
  elements.themeToggle.innerHTML = `<span aria-hidden="true">${isDark ? "☀" : "☾"}</span>`;
  elements.themeToggle.setAttribute(
    "aria-label",
    isDark ? "Switch to light mode" : "Switch to dark mode"
  );
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
