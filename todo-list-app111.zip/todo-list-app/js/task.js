const API_URL = "/api/tasks";
const LOCAL_STORAGE_KEY = "taskflow_tasks";
const THEME_KEY = "taskflow_theme";

const state = {
  task: null,
  storageMode: "checking"
};

const elements = {
  loading: document.querySelector("#detail-loading"),
  error: document.querySelector("#detail-error"),
  content: document.querySelector("#detail-content"),
  form: document.querySelector("#detail-form"),
  titleHeading: document.querySelector("#current-task-title"),
  title: document.querySelector("#detail-title"),
  description: document.querySelector("#detail-description"),
  dueDate: document.querySelector("#detail-due-date"),
  priority: document.querySelector("#detail-priority"),
  completed: document.querySelector("#detail-completed"),
  statusBadge: document.querySelector("#detail-status-badge"),
  titleError: document.querySelector("#detail-title-error"),
  deleteButton: document.querySelector("#delete-detail-task"),
  toast: document.querySelector("#toast")
};

document.addEventListener("DOMContentLoaded", initializePage);

async function initializePage() {
  initializeTheme();

  const taskId = new URLSearchParams(window.location.search).get("id");

  if (!taskId) {
    showError();
    return;
  }

  elements.form.addEventListener("submit", handleSave);
  elements.deleteButton.addEventListener("click", handleDelete);
  elements.completed.addEventListener("change", updateStatusBadge);
  elements.title.addEventListener("input", clearTitleError);

  await loadTask(taskId);
}

async function loadTask(taskId) {
  try {
    const response = await fetch(`${API_URL}/${encodeURIComponent(taskId)}`, {
      headers: { Accept: "application/json" }
    });

    if (!response.ok) {
      throw new Error("API task not found");
    }

    state.task = await response.json();
    state.storageMode = "api";
  } catch (error) {
    const localTasks = readLocalTasks();
    state.task = localTasks.find((task) => task._id === taskId) || null;
    state.storageMode = "local";
  }

  if (!state.task) {
    showError();
    return;
  }

  populateForm();
}

function populateForm() {
  elements.loading.classList.add("hidden");
  elements.error.classList.add("hidden");
  elements.content.classList.remove("hidden");

  elements.titleHeading.textContent = state.task.title;
  elements.title.value = state.task.title;
  elements.description.value = state.task.description || "";
  elements.dueDate.value = normalizeDateForInput(state.task.dueDate);
  elements.priority.value = state.task.priority || "medium";
  elements.completed.checked = Boolean(state.task.completed);

  updateStatusBadge();
}

async function handleSave(event) {
  event.preventDefault();

  const title = elements.title.value.trim();

  if (!title) {
    showTitleError("Please enter a task title.");
    elements.title.focus();
    return;
  }

  const updates = {
    title,
    description: elements.description.value.trim(),
    dueDate: elements.dueDate.value || null,
    priority: elements.priority.value,
    completed: elements.completed.checked
  };

  try {
    if (state.storageMode === "api") {
      const response = await fetch(`${API_URL}/${encodeURIComponent(state.task._id)}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates)
      });

      if (!response.ok) {
        throw new Error("Unable to update task");
      }

      state.task = await response.json();
    } else {
      state.task = {
        ...state.task,
        ...updates,
        updatedAt: new Date().toISOString()
      };

      const localTasks = readLocalTasks().map((task) =>
        task._id === state.task._id ? state.task : task
      );

      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(localTasks));
    }

    populateForm();
    showToast("Task changes saved.");
  } catch (error) {
    showToast("Unable to save changes.");
  }
}

async function handleDelete() {
  const confirmed = window.confirm(`Delete "${state.task.title}"?`);

  if (!confirmed) {
    return;
  }

  try {
    if (state.storageMode === "api") {
      const response = await fetch(`${API_URL}/${encodeURIComponent(state.task._id)}`, {
        method: "DELETE"
      });

      if (!response.ok) {
        throw new Error("Unable to delete task");
      }
    } else {
      const localTasks = readLocalTasks().filter(
        (task) => task._id !== state.task._id
      );
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(localTasks));
    }

    window.location.href = "main.html";
  } catch (error) {
    showToast("Unable to delete the task.");
  }
}

function updateStatusBadge() {
  const isCompleted = elements.completed.checked;
  elements.statusBadge.textContent = isCompleted ? "Completed" : "Active";
  elements.statusBadge.classList.toggle("completed", isCompleted);
}

function showError() {
  elements.loading.classList.add("hidden");
  elements.content.classList.add("hidden");
  elements.error.classList.remove("hidden");
}

function normalizeDateForInput(value) {
  if (!value) {
    return "";
  }

  return String(value).slice(0, 10);
}

function readLocalTasks() {
  try {
    const tasks = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY));
    return Array.isArray(tasks) ? tasks : [];
  } catch (error) {
    return [];
  }
}

function showTitleError(message) {
  elements.titleError.textContent = message;
  elements.title.setAttribute("aria-invalid", "true");
}

function clearTitleError() {
  elements.titleError.textContent = "";
  elements.title.removeAttribute("aria-invalid");
}

let toastTimer;

function showToast(message) {
  window.clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.add("visible");

  toastTimer = window.setTimeout(() => {
    elements.toast.classList.remove("visible");
  }, 2600);
}

function initializeTheme() {
  const savedTheme = localStorage.getItem(THEME_KEY);
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const useDarkTheme = savedTheme ? savedTheme === "dark" : prefersDark;
  document.body.classList.toggle("dark-theme", useDarkTheme);
}
