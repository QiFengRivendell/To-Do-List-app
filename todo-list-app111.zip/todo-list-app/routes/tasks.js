const express = require("express");
const mongoose = require("mongoose");
const Task = require("../models/Task");

const router = express.Router();

router.get("/", async (request, response, next) => {
  try {
    const tasks = await Task.find().sort({
      completed: 1,
      priority: -1,
      createdAt: -1
    });

    response.json(tasks);
  } catch (error) {
    next(error);
  }
});

router.get("/:id", async (request, response, next) => {
  try {
    if (!mongoose.isValidObjectId(request.params.id)) {
      return response.status(400).json({ message: "Invalid task ID." });
    }

    const task = await Task.findById(request.params.id);

    if (!task) {
      return response.status(404).json({ message: "Task not found." });
    }

    response.json(task);
  } catch (error) {
    next(error);
  }
});

router.post("/", async (request, response, next) => {
  try {
    const task = await Task.create({
      title: request.body.title,
      description: request.body.description,
      dueDate: request.body.dueDate || null,
      priority: request.body.priority,
      completed: Boolean(request.body.completed)
    });

    response.status(201).json(task);
  } catch (error) {
    next(error);
  }
});

router.put("/:id", async (request, response, next) => {
  try {
    if (!mongoose.isValidObjectId(request.params.id)) {
      return response.status(400).json({ message: "Invalid task ID." });
    }

    const task = await Task.findByIdAndUpdate(
      request.params.id,
      {
        title: request.body.title,
        description: request.body.description,
        dueDate: request.body.dueDate || null,
        priority: request.body.priority,
        completed: Boolean(request.body.completed)
      },
      {
        new: true,
        runValidators: true,
        overwrite: false
      }
    );

    if (!task) {
      return response.status(404).json({ message: "Task not found." });
    }

    response.json(task);
  } catch (error) {
    next(error);
  }
});

router.patch("/:id", async (request, response, next) => {
  try {
    if (!mongoose.isValidObjectId(request.params.id)) {
      return response.status(400).json({ message: "Invalid task ID." });
    }

    const allowedFields = [
      "title",
      "description",
      "dueDate",
      "priority",
      "completed"
    ];

    const updates = {};

    allowedFields.forEach((field) => {
      if (Object.prototype.hasOwnProperty.call(request.body, field)) {
        updates[field] =
          field === "dueDate" && !request.body[field]
            ? null
            : request.body[field];
      }
    });

    const task = await Task.findByIdAndUpdate(request.params.id, updates, {
      new: true,
      runValidators: true
    });

    if (!task) {
      return response.status(404).json({ message: "Task not found." });
    }

    response.json(task);
  } catch (error) {
    next(error);
  }
});

router.delete("/:id", async (request, response, next) => {
  try {
    if (!mongoose.isValidObjectId(request.params.id)) {
      return response.status(400).json({ message: "Invalid task ID." });
    }

    const task = await Task.findByIdAndDelete(request.params.id);

    if (!task) {
      return response.status(404).json({ message: "Task not found." });
    }

    response.json({ message: "Task deleted successfully." });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
