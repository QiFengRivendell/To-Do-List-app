# TaskFlow Wireframes

## 1. Task list page

```text
+------------------------------------------------------------------+
| TaskFlow                                             Theme Button |
+------------------------------------------------------------------+
| Organize your day                    Overall Progress [====== 60%]|
+--------------------------+---------------------------------------+
| ADD A TASK               | Total      Active      Completed      |
|                          +---------------------------------------+
| Task title               | MY TASKS                              |
| [____________________]   | [Search________] [All][Active][Done] |
|                          |                                       |
| Description              | [ ] Finish report       HIGH          |
| [____________________]   |     Due Jul 20      [Edit] [Delete]   |
| [____________________]   |                                       |
|                          | [x] Submit homework      MEDIUM        |
| Due date   Priority      |     Completed        [Edit] [Delete]  |
| [_______]  [Medium v]    |                                       |
|                          |                                       |
| [      Add task      ]   |                                       |
+--------------------------+---------------------------------------+
```

## 2. Task detail page

```text
+------------------------------------------------------------------+
| TaskFlow                                       Back to task list |
+------------------------------------------------------------------+
| TASK DETAIL VIEW                                                 |
| Task details                                                     |
|                                                                  |
| +--------------------------------------------------------------+ |
| | EDIT TASK                                         [Active]   | |
| |                                                              | |
| | Task title                                                   | |
| | [__________________________________________________________] | |
| |                                                              | |
| | Description                                                  | |
| | [__________________________________________________________] | |
| | [__________________________________________________________] | |
| |                                                              | |
| | Due date                      Priority                        | |
| | [____________]                [Medium v]                      | |
| |                                                              | |
| | [ ] Mark this task as completed                              | |
| |                                                              | |
| | [Save changes] [Delete task]                                 | |
| +--------------------------------------------------------------+ |
+------------------------------------------------------------------+
```

## Responsive behavior

- On wide screens, the add-task form appears beside the task list.
- Below approximately 900px, the form moves above the task list.
- On narrow phones, form fields and controls stack vertically.
- Task action buttons move below the task information when needed.
