# TaskFlow To-Do List App

TaskFlow is a responsive full-stack to-do list project designed at the level of a college web-development final assignment.

## Main features

- Add a task with title, description, due date, and priority
- Validate required form input
- Mark tasks complete or active
- Delete tasks
- Search and filter tasks
- View and edit a task on a separate detail page
- Show task totals and completion progress
- Save data in LocalStorage when the back-end is unavailable
- Use a Node.js/Express REST API and MongoDB when the server is running
- Responsive layout for desktop, tablet, and mobile
- Semantic HTML and accessibility features
- Light and dark themes

## Project structure

```text
todo-list-app/
├── main.html
├── task.html
├── css/
│   └── styles.css
├── js/
│   ├── app.js
│   └── task.js
├── models/
│   └── Task.js
├── routes/
│   └── tasks.js
├── server.js
├── package.json
├── .env.example
├── .gitignore
├── WIREFRAMES.md
└── README.md
```

## Option 1: Run only the front-end

This is the easiest way to test the project.

1. Open the project folder in Visual Studio Code.
2. Open `main.html`.
3. Use the VS Code **Live Server** extension, or open the file in a browser.
4. The app will automatically use browser LocalStorage.

No database is required in this mode.

## Option 2: Run the full-stack version

### Requirements

- Node.js
- npm
- MongoDB Community Server, or a MongoDB Atlas database

### Installation

Open the project folder in the VS Code terminal and run:

```bash
npm install
```

Copy `.env.example` to a new file named `.env`.

For local MongoDB, this value can remain:

```env
PORT=3000
MONGODB_URI=mongodb://127.0.0.1:27017/taskflow
```

Start MongoDB, then run:

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

When the API is connected, the top of the task list displays **MongoDB API connected**. Otherwise, the front-end uses LocalStorage.

## REST API routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/tasks` | Get all tasks |
| GET | `/api/tasks/:id` | Get one task |
| POST | `/api/tasks` | Create a task |
| PUT | `/api/tasks/:id` | Replace task fields |
| PATCH | `/api/tasks/:id` | Update selected fields |
| DELETE | `/api/tasks/:id` | Delete a task |

## Suggested Git commands

```bash
git init
git add .
git commit -m "Create TaskFlow to-do list app"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Final testing checklist

- Add a valid task
- Try submitting an empty title
- Complete and uncomplete a task
- Delete a task
- Search by title or description
- Test All, Active, and Completed filters
- Refresh and confirm LocalStorage persistence
- Open task details and save edits
- Resize the browser to mobile width
- Test keyboard navigation
- Test the application with the MongoDB API
